var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.ts
var src_exports = {};
__export(src_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(src_exports);
var healthPath = "/health";
var imagePath = "/image";
var imagesPath = "/images";
var handler = async (event) => {
  console.log("event:", event);
  let response;
  try {
    switch (true) {
      case (event.httpMethod === "GET" && event.path === healthPath):
        response = buildResponse(200, { Message: "SUCCESS" });
        break;
      case (event.httpMethod === "POST" && event.path === imagePath):
        response = buildResponse(200, { Message: "SUCCESS" });
        break;
      case (event.httpMethod === "GET" && event.path === imagePath):
        const { key } = event.queryStringParameters;
        response = buildResponse(200, { Message: "SUCCESS" });
        break;
      case (event.httpMethod === "DELETE" && event.path === imagePath):
        response = buildResponse(200, { Message: "SUCCESS" });
        break;
      case (event.httpMethod === "GET" && event.path === imagesPath):
        response = buildResponse(200, { Message: "SUCCESS" });
        break;
      default:
        response = buildResponse(404, "404 Not Found");
    }
    return response;
  } catch (err) {
    return buildResponse(404, "404 Not Found");
  }
};
var buildResponse = (statusCode, body) => {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,X-Amz-User-Agent",
      "Access-Control-Allow-Credentials": "true",
      "Access-Control-Allow-Methods": "*",
      "Access-Control-Allow-Origin": "*"
    },
    body: JSON.stringify(body)
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
